//
//  Aula07HackaApp.swift
//  Aula07Hacka
//
//  Created by edilsonalmeida on 29/02/24.
//

import SwiftUI

@main
struct Aula07HackaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
