//
//  SegundaTela.swift
//  Aula07Hacka
//
//  Created by edilsonalmeida on 29/02/24.
//

import SwiftUI

struct SegundaTela: View {
    
    var nomeRecebido : String
    
    var body: some View {
        HStack{
            Text("O valor chegou")
            Text(nomeRecebido)
                .foregroundStyle(.blue)
                .bold()
        }
    }
}

#Preview {
    
    SegundaTela(nomeRecebido: "Juninho")
    
}
