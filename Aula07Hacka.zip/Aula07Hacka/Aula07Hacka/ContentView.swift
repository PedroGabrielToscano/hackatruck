//
//  ContentView.swift
//  Aula07Hacka
//
//  Created by edilsonalmeida on 29/02/24.
//

import SwiftUI

struct ContentView: View {
    
    @State var nome : String = ""
    
    var body: some View {
        NavigationStack{
            VStack {
                Image(systemName: "rectangle.portrait.and.arrow.right.fill")
                    .imageScale(.large)
                    .foregroundStyle(.tint)
                Text("Olá, \(nome)")
                
                TextField("Nome", text: $nome)
                    .padding(.horizontal, 20)
                    .multilineTextAlignment(.center)
                
                NavigationLink("Enviar Valor", destination: SegundaTela(nomeRecebido: nome)).buttonStyle(.borderedProminent)
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}

